b-tree data structure.
Include bTree.h in a C++ program to have access to my implementation of b-trees.
Read bTree.h to see how to use it.
Note that bTree.h includes bTree.cpp and so you need to download bTree.cpp as well.
